'use strict';
/* ==========================================================
   game.js - Engine loop, state machine, HUD, extraction, terminal.
   States: menu -> playing -> (caught -> playing) | (terminal -> playing)
   Progress (stash, upgrades, lore) is saved in localStorage.
   Sound is optional: if js/audio.js defines window.Sfx it is used.
   ========================================================== */
(() => {
  const $ = id => document.getElementById(id);
  const canvas = $('game'), ctx = canvas.getContext('2d');
  const glitch = $('glitch');
  const sfx = (name, ...a) => { try { if (window.Sfx && Sfx[name]) Sfx[name](...a); } catch (e) { /* audio must never crash the game */ } };

  /* ---------- Tuning ---------- */
  const BASE_DRAIN = 1.8;       // battery % per second before upgrades
  const NEED_ITEMS = 3;         // items looted this run required to extract
  const MAX_DRAIN_LV = 8, MAX_BOOTS = 3, MAX_HANDS = 3;

  /* ---------- Lore: one connected mystery, revealed by decrypting drives ---------- */
  const LORE = [
    'LOG 001 // Sublevel 9 was sealed when the night shift stopped answering their radios. The elevator still runs. Nobody called it.',
    'LOG 014 // We added sound-dampening foam to stop the humming. The humming was never coming from the machines.',
    'LOG 022 // Technician R. Vale requested new eyes. Not glasses. Eyes. Request denied. He stopped asking. He started listening.',
    'LOG 031 // It does not hunt by sight. Whatever is down there learned to find us by our footsteps.',
    'LOG 037 // The glass on the floor was broken on purpose. It helps us know where HE is. Please stop sweeping it up.',
    'LOG 045 // Batteries die faster near him. He eats the light. Or the light is what is left of whatever he ate.',
    'LOG 052 // Scrap tapped against a pipe makes him turn. Throw it far, then walk the other way. Quietly.',
    'LOG 060 // The drives are not storage. They are memory. Ours. Every one you decrypt, he forgets a little less.',
    'LOG 066 // The elevator never went up. We only ever went down. You have extracted [CORRUPTED] times already.',
    'LOG 070 // Vale is not the stalker. Vale is the one holding the flashlight. Look at your hands.'
  ];

  /* ---------- Saved progress ---------- */
  const SAVE_KEY = 'blindDepthsSave';
  let save = { scrap: 0, drives: 0, batteries: 0, drain: 0, boots: 0, hands: 0, lore: 0, depth: 1, runs: 0, deaths: 0 };
  try { Object.assign(save, JSON.parse(localStorage.getItem(SAVE_KEY) || '{}')); } catch (e) { /* ignore */ }
  const persist = () => { try { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); } catch (e) { /* ignore */ } };

  /* ---------- Runtime state ---------- */
  let state = 'menu';                 // menu | playing | caught | terminal
  let map, player, stalker;
  let W = 0, H = 0, dpr = 1;
  const camBase = { x: 0, y: 0 }, cam = { x: 0, y: 0 };   // cam = camBase + shake
  let shake = 0, runTime = 0, lootedThisRun = 0, caughtT = 0;
  let msg = '', msgT = 0, lastInv = '', lastRipple = null, deadBatteryShown = false;
  const keys = new Set(), mouse = { x: 0, y: 0 };          // mouse in screen px
  window.GameAim = window.GameAim || { x: 1, y: 0, active: false }; // touch aim stick (see touch.js)

  const setMsg = (t, s = 2) => { msg = t; msgT = s; };

  /* ---------- Canvas sizing ---------- */
  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 1.5);     // cap for performance on phones
    W = window.innerWidth; H = window.innerHeight;
    canvas.width = W * dpr; canvas.height = H * dpr;
  }
  window.addEventListener('resize', resize); resize();
  glitch.width = 160; glitch.height = 90; glitch.style.imageRendering = 'pixelated';

  /* ---------- Upgrades -> player stats ---------- */
  function applyUpgrades() {
    player.drainRate = BASE_DRAIN * Math.pow(0.88, save.drain);   // sell scrap: slower drain
    player.ripScale = Math.pow(0.85, save.boots);                 // quiet boots: smaller ripples
    player.interact.duration = 1.6 * Math.pow(0.85, save.hands);  // quick hands: faster looting
  }

  /* ---------- Run lifecycle ---------- */
  function startRun(message) {
    map = new GameMap();                                          // new layout every run
    if (!player) player = new Player(map.spawn.x, map.spawn.y);
    player.respawn(map.spawn.x, map.spawn.y);
    const carry = Math.min(2, save.batteries);                    // bring up to 2 stashed batteries
    save.batteries -= carry;
    for (let i = 0; i < carry; i++) player.inventory.push('battery');
    applyUpgrades();
    stalker = new Stalker(map.stalkerSpawn.x, map.stalkerSpawn.y);
    runTime = 0; lootedThisRun = 0; shake = 0; deadBatteryShown = false; lastInv = ''; lastRipple = null;
    state = 'playing';
    $('start-screen').classList.add('hidden'); $('terminal').classList.add('hidden');
    glitch.classList.add('hidden'); $('hud').classList.remove('hidden');
    setMsg(message || '', 3);
    persist();
  }

  /** Stalker difficulty: grows with time in the run and with depth. */
  const aggression = () => 1 + Math.min(0.5, runTime / 180) + Math.min(0.4, (save.depth - 1) * 0.04);

  function canExtract() { return state === 'playing' && map.inElevator(player.x, player.y) && lootedThisRun >= NEED_ITEMS; }

  /** Success: move inventory to the stash and open the terminal. */
  function extract() {
    if (!canExtract()) return;
    let scrap = 0, drives = 0, bats = 0;
    for (const id of player.inventory) { if (id === 'scrap') scrap++; else if (id === 'drive') drives++; else bats++; }
    save.scrap += scrap; save.drives += drives; save.batteries += bats; save.runs++; save.depth++;
    persist(); sfx('extract'); sfx('pulse', 0);
    state = 'terminal'; $('hud').classList.add('hidden'); $('terminal').classList.remove('hidden');
    $('term-log').innerHTML = ''; q.length = 0;
    termPrint(`EXTRACTION CONFIRMED. DEPTH ${save.depth - 1} CLEARED.`);
    termPrint(`RECOVERED: ${scrap} scrap, ${drives} drive(s), ${bats} battery(s).`);
    termPrint('Sell scrap for upgrades. Decrypt drives. Then descend again.');
    renderTerminal();
  }

  /** Failure: static, inventory deleted, wake up in the hub with a fresh map. */
  function caught() {
    state = 'caught'; caughtT = 1.6; save.deaths++; persist();
    player.inventory = []; player.panic = false; player.interact.progress = 0;
    sfx('caught'); sfx('pulse', 0);
    glitch.classList.remove('hidden');
  }

  /* ---------- Terminal (metagame) ---------- */
  const q = []; let typing = false;
  function termPrint(text, cls = '') { q.push([text, cls]); if (!typing) pump(); }
  function pump() {                                               // typewriter effect
    const it = q.shift();
    if (!it) { typing = false; return; }
    typing = true;
    const log = $('term-log'), d = document.createElement('div');
    if (it[1]) d.className = it[1];
    log.appendChild(d);
    let i = 0;
    const step = () => {
      d.textContent = it[0].slice(0, i += 3); log.scrollTop = log.scrollHeight;
      if (i < it[0].length) setTimeout(step, 12); else pump();
    };
    step();
  }
  function corrupt(t, p = 0.06) {                                 // random glitch characters
    const junk = '#%&$@?01<>/\\|';
    return t.replace(/[A-Za-z]/g, c => (Math.random() < p ? junk[Math.floor(Math.random() * junk.length)] : c));
  }
  function renderTerminal() {
    $('term-scrap').textContent = save.scrap; $('term-drives').textContent = save.drives;
    $('term-batteries').textContent = save.batteries; $('term-level').textContent = save.drain;
    const s = $('btn-sell'), b = $('btn-boots'), h = $('btn-hands'), d = $('btn-decrypt');
    s.textContent = `> SELL 1 SCRAP: SLOWER DRAIN [${save.drain}/${MAX_DRAIN_LV}]`;
    s.disabled = save.scrap < 1 || save.drain >= MAX_DRAIN_LV;
    b.textContent = `> QUIET BOOTS: 2 SCRAP [${save.boots}/${MAX_BOOTS}]`;
    b.disabled = save.scrap < 2 || save.boots >= MAX_BOOTS;
    h.textContent = `> QUICK HANDS: 2 SCRAP [${save.hands}/${MAX_HANDS}]`;
    h.disabled = save.scrap < 2 || save.hands >= MAX_HANDS;
    d.textContent = `> DECRYPT DRIVE (${save.drives})`; d.disabled = save.drives < 1;
  }
  $('btn-sell').onclick = () => {
    save.scrap--; save.drain++; persist(); renderTerminal();
    termPrint(`Scrap sold. Battery drain now ${(BASE_DRAIN * Math.pow(0.88, save.drain)).toFixed(2)}%/s.`);
  };
  $('btn-boots').onclick = () => { save.scrap -= 2; save.boots++; persist(); renderTerminal(); termPrint('Boots padded. Your footsteps carry less.'); };
  $('btn-hands').onclick = () => { save.scrap -= 2; save.hands++; persist(); renderTerminal(); termPrint('Hands steadied. Containers open faster.'); };
  $('btn-decrypt').onclick = () => {
    save.drives--;
    const n = save.lore, fresh = n < LORE.length;
    if (fresh) save.lore++;
    persist(); renderTerminal();
    if (fresh) { termPrint(`[FRAGMENT ${n + 1}/${LORE.length}] DECRYPTING...`); termPrint(corrupt(LORE[n]), 'corrupt'); }
    else { termPrint('ARCHIVE COMPLETE. RESIDUAL ECHO:', 'warn'); termPrint(corrupt(LORE[Math.floor(Math.random() * LORE.length)], 0.25), 'corrupt'); }
  };
  $('btn-deploy').onclick = () => { sfx('init'); startRun('DESCENDING... STAY QUIET.'); };

  /* ---------- Input ---------- */
  window.addEventListener('keydown', e => {
    const k = e.key.toLowerCase();
    if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(k)) e.preventDefault();
    const fresh = !e.repeat; keys.add(k);
    if (!fresh || state !== 'playing') return;
    if (k === 'q') { setMsg(player.useBattery() ? 'BATTERY INSERTED +40%' : 'NO BATTERY (OR ALREADY FULL)', 1.5); }
    else if (k === 'f') { const p = player.throwDecoy(map); if (p) { sfx('clink'); setMsg('SCRAP THROWN', 1); } else setMsg('NO SCRAP TO THROW', 1.2); }
    else if (k === 'enter') extract();
  });
  window.addEventListener('keyup', e => keys.delete(e.key.toLowerCase()));
  window.addEventListener('blur', () => keys.clear());
  window.addEventListener('mousemove', e => { mouse.x = e.clientX; mouse.y = e.clientY; });
  $('start-btn').onclick = () => { sfx('init'); startRun(); };
  $('extract-btn').onclick = extract;

  /* ---------- HUD ---------- */
  const slots = [];
  for (let i = 0; i < 12; i++) { const d = document.createElement('div'); d.className = 'slot'; $('inventory').appendChild(d); slots.push(d); }

  function updateHud() {
    const b = Math.round(player.battery);
    $('battery-fill').style.width = b + '%'; $('battery-text').textContent = b + '%';
    $('battery-fill').classList.toggle('low', b < 20);
    const inv = player.inventory.join(',');
    if (inv !== lastInv) {                                         // only touch the DOM when it changes
      lastInv = inv;
      slots.forEach((s, i) => {
        const it = ITEMS[player.inventory[i]];
        s.className = 'slot' + (it ? ' full ' + (it.id === 'drive' ? 'drive' : it.id === 'scrap' ? 'scrap' : 'battery') : '');
        s.textContent = it ? it.label : '';
      });
      $('inv-count').textContent = `${player.inventory.length}/${player.maxSlots}`;
    }
    let text = msgT > 0 ? msg : '';
    if (!text && player.nearLoot) text = 'HOLD [E] TO SEARCH';
    else if (!text && map.inElevator(player.x, player.y) && lootedThisRun < NEED_ITEMS) text = `LOOT ${NEED_ITEMS - lootedThisRun} MORE TO EXTRACT`;
    $('status-msg').textContent = text;
    $('extract-btn').classList.toggle('hidden', !canExtract());
  }

  /* ---------- Update ---------- */
  function update(dt) {
    if (state === 'playing') {
      runTime += dt; msgT -= dt;
      const A = window.GameAim;
      const mouseWorld = A.active                                   // touch: aim along the stick direction
        ? { x: player.x + A.x * 200, y: player.y + A.y * 200 }
        : { x: mouse.x + camBase.x, y: mouse.y + camBase.y };
      const ev = player.update(dt, { keys, mouse: mouseWorld }, map);
      if (ev && ev.type === 'loot') { lootedThisRun++; sfx('loot'); setMsg('FOUND: ' + ev.item.name.toUpperCase(), 2); }
      else if (ev && ev.type === 'full') setMsg('INVENTORY FULL', 1.5);

      stalker.update(dt, player, map, aggression());
      player.panic = stalker.inBeam;                               // flicker the beam when it is lit
      if (stalker.inBeam) shake = Math.max(shake, 9);              // violent camera jitter
      else shake = Math.max(0, shake - 30 * dt);
      if (stalker.screeched) { shake = Math.max(shake, 16); sfx('screech'); }

      // footstep sound whenever a new ripple appears
      const lr = player.ripples[player.ripples.length - 1];
      if (lr && lr !== lastRipple) { lastRipple = lr; if (!lr.decoy) sfx('step', lr.glass, player.sneaking); }
      // heartbeat grows as the stalker closes in
      sfx('pulse', Math.max(0, 1 - stalker.distTo(player) / 520));

      if (player.battery <= 0 && !deadBatteryShown) { deadBatteryShown = true; setMsg('BATTERY DEAD. PRESS Q IF YOU HAVE ONE.', 3); }
      if (stalker.distTo(player) < stalker.r + player.radius) caught();
      updateHud();
    } else if (state === 'caught') {
      caughtT -= dt; shake = 18;
      drawGlitch();
      if (caughtT <= 0) startRun('YOU WOKE UP IN THE HUB. THE DEPTHS HAVE SHIFTED.');
    }

    if (map && (state === 'playing' || state === 'caught')) {
      // camera follows the player, clamped to the world; shake is added on top
      camBase.x = map.width <= W ? (map.width - W) / 2 : Math.max(0, Math.min(map.width - W, player.x - W / 2));
      camBase.y = map.height <= H ? (map.height - H) / 2 : Math.max(0, Math.min(map.height - H, player.y - H / 2));
      cam.x = camBase.x + (Math.random() - 0.5) * shake * 2;
      cam.y = camBase.y + (Math.random() - 0.5) * shake * 2;
    }
  }

  function drawGlitch() {                                          // low-res TV static
    const g = glitch.getContext('2d'), w = glitch.width, h = glitch.height;
    const img = g.createImageData(w, h), d = img.data;
    for (let i = 0; i < d.length; i += 4) { const v = Math.random() * 255; d[i] = d[i + 1] = d[i + 2] = v; d[i + 3] = 255; }
    g.putImageData(img, 0, 0);
    for (let i = 0; i < 4; i++) { g.fillStyle = 'rgba(255,0,60,0.3)'; g.fillRect(0, Math.random() * h, w, 1 + Math.random() * 6); }
  }

  /* ---------- Render ---------- */
  function render(t) {
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
    if (!map || (state !== 'playing' && state !== 'caught')) return;
    map.draw(ctx, cam, W, H, t);                                   // world
    stalker.draw(ctx, cam, t);                                     // hidden unless lit
    player.drawBody(ctx, cam);
    player.drawDarkness(ctx, cam, W, H);                           // the blind dark
    player.drawRipples(ctx, cam);                                  // sound is always visible
    stalker.drawRings(ctx, cam);
    player.drawInteract(ctx, cam);
  }

  /* ---------- Main loop (requestAnimationFrame ~60 FPS) ---------- */
  let last = performance.now();
  function frame(now) {
    const dt = Math.min(0.05, (now - last) / 1000);                // clamp so tab-switching can't teleport things
    last = now;
    update(dt); render(now / 1000);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
