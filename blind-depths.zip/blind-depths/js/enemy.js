'use strict';
/* ==========================================================
   enemy.js - The Blind Stalker.
   It has NO eyes. It reacts to two things only:
     1) the flashlight beam touching its body  -> targets the player
     2) a sound ripple ring touching its body  -> targets where the sound began
   States: patrol -> windup (screech) -> charge -> search -> patrol
   `aggr` (1.0+) scales speed; game.js raises it over time and depth.
   ========================================================== */

class Stalker {
  constructor(x, y) {
    this.x = x; this.y = y; this.r = 13;
    this.state = 'patrol';
    this.timer = 0;             // used by windup / search / patrol pause
    this.path = []; this.pi = 0; this.repath = 0;
    this.target = null;         // last known location it is heading to
    this.inBeam = false;        // read by game.js (camera shake + flicker)
    this.screeched = false;     // one-frame event flag for game.js (sound)
    this.rings = [];            // screech rings (drawn above the darkness)
    this.facing = 0;
    this.patrolSpeed = 70;
    this.chargeSpeed = 185;     // player walks at 150, so running in the open fails
  }

  /** Distance to a point. */
  distTo(p) { return Math.hypot(p.x - this.x, p.y - this.y); }

  update(dt, player, map, aggr = 1) {
    this.screeched = false;

    // ----- SENSES -----
    this.inBeam = player.isInBeam(this.x, this.y, this.r, map);
    const ripple = player.rippleTouches(this.x, this.y, this.r);
    let stimulus = null;
    if (this.inBeam) stimulus = { x: player.x, y: player.y };      // sees the light: knows exactly where you are
    else if (ripple) stimulus = { x: ripple.x, y: ripple.y };      // heard noise: goes to where it began

    if (stimulus) {
      this.target = stimulus;
      if (this.state === 'patrol' || this.state === 'search') {
        this.state = 'windup'; this.timer = 0.4; this.path = [];   // short screech before the charge
        this.screech();
      } else if (this.state === 'charge') {
        this.repath = Math.min(this.repath, 0.1);                  // fresh stimulus: re-plan soon
      }
    }

    // ----- STATE MACHINE -----
    switch (this.state) {
      case 'windup':
        this.timer -= dt;
        if (this.target) this.facing = Math.atan2(this.target.y - this.y, this.target.x - this.x);
        if (this.timer <= 0) { this.state = 'charge'; this.repath = 0; }
        break;
      case 'charge': this.chase(dt, map, aggr); break;
      case 'search':
        this.timer -= dt; this.facing += dt * 2.2;                 // sweeps its head, listening
        if (this.timer <= 0) { this.state = 'patrol'; this.path = []; }
        break;
      default: this.patrol(dt, map, aggr);
    }

    // ----- screech rings -----
    for (const g of this.rings) g.r += g.speed * dt;
    this.rings = this.rings.filter(g => g.r < g.maxR);
  }

  patrol(dt, map, aggr) {
    if (this.timer > 0) { this.timer -= dt; return; }              // brief pause at each stop
    if (this.pi >= this.path.length) {
      const p = map.randomFloorPoint();
      this.setPath(map.findPath(this.x, this.y, p.x, p.y));
      this.timer = 0.6;
      return;
    }
    this.followPath(dt, this.patrolSpeed * aggr, map);
  }

  chase(dt, map, aggr) {
    this.repath -= dt;
    if (this.repath <= 0 || !this.path.length) {
      const p = map.findPath(this.x, this.y, this.target.x, this.target.y);
      p.push({ x: this.target.x, y: this.target.y });              // finish on the exact spot
      this.setPath(p); this.repath = 0.3;
    }
    const done = this.followPath(dt, this.chargeSpeed * aggr, map);
    if (done || this.distTo(this.target) < 16) {                   // reached it, nothing new heard
      this.state = 'search'; this.timer = 2.5; this.path = [];
    }
  }

  /**
   * Adopt a new path. If we are already past the first tile centre (between it
   * and the second), skip it - otherwise every re-plan would drag us backwards.
   */
  setPath(p) {
    this.path = p; this.pi = 0;
    if (p.length > 1) {
      const a = p[0], b = p[1];
      if (Math.hypot(a.x - this.x, a.y - this.y) < 6 ||
          Math.hypot(b.x - this.x, b.y - this.y) < Math.hypot(b.x - a.x, b.y - a.y)) this.pi = 1;
    }
  }

  /** Walk toward the current waypoint. Returns true when the path is finished. */
  followPath(dt, speed, map) {
    if (this.pi >= this.path.length) return true;
    const w = this.path[this.pi];
    const dx = w.x - this.x, dy = w.y - this.y, d = Math.hypot(dx, dy), step = speed * dt;
    if (d <= step) { this.x = w.x; this.y = w.y; this.pi++; }
    else { map.moveCircle(this, (dx / d) * step, (dy / d) * step, this.r * 0.8); this.facing = Math.atan2(dy, dx); }
    return this.pi >= this.path.length;
  }

  /** Emit a red ring so the player learns where it is (even in the dark). */
  screech() {
    this.rings.push({ x: this.x, y: this.y, r: 10, maxR: 340, speed: 420 });
    this.screeched = true;
  }

  /* ---------- RENDERING ---------- */
  /** Hunched creature with long clawed arms. Drawn BEFORE the darkness, so it only shows inside the beam. */
  draw(ctx, cam, t) {
    const hot = this.state === 'charge' || this.state === 'windup';
    const sw = Math.sin(t * (hot ? 20 : 5));                       // arm / body twitch
    const reach = hot ? 1 : 0.4;
    ctx.save();
    ctx.translate(this.x - cam.x, this.y - cam.y);
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    ctx.beginPath(); ctx.ellipse(0, 4, 20, 16, 0, 0, Math.PI * 2); ctx.fill();
    ctx.rotate(this.facing);

    ctx.lineCap = 'round';
    for (const side of [-1, 1]) {                                  // two long arms reaching forward
      const hx = 24 + side * sw * 6 * reach, hy = side * (15 + sw * 2 * reach);
      ctx.strokeStyle = hot ? '#7a0f20' : '#3a1620'; ctx.lineWidth = 5;
      ctx.beginPath(); ctx.moveTo(0, side * 9); ctx.quadraticCurveTo(14, side * 22, hx, hy); ctx.stroke();
      ctx.strokeStyle = '#d9cccc'; ctx.lineWidth = 1.8;            // claws
      for (let k = -1; k <= 1; k++) { ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(hx + 9, hy + k * 4 + side * 2); ctx.stroke(); }
    }

    ctx.fillStyle = hot ? '#9b1226' : '#4d1b25';                   // hunched, jagged torso
    ctx.beginPath();
    for (let i = 0; i < 14; i++) {
      const a = (i / 14) * Math.PI * 2;
      const rad = this.r * (i % 2 ? 0.85 : 1.3) + Math.sin(t * (hot ? 22 : 6) + i * 1.7) * (hot ? 2.5 : 1);
      const px = Math.cos(a) * rad * 1.1 - 3, py = Math.sin(a) * rad;
      i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
    }
    ctx.closePath(); ctx.fill();

    ctx.fillStyle = '#d9cccc';                                     // pale, long, eyeless head
    ctx.beginPath(); ctx.ellipse(9, 0, 9, 7, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#1a0508';                                     // mouth: a gash, wide open when hunting
    ctx.beginPath(); ctx.ellipse(13, 0, hot ? 4 : 3, hot ? 3.5 + Math.abs(sw) * 2 : 0.8, 0, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  /**
   * JUMPSCARE: giant face rushing at the camera. p = progress 0..1.
   * Drawn on its own full-screen canvas by game.js when you are caught.
   */
  static drawJumpscare(g, w, h, p) {
    const flash = p < 0.1 && Math.random() < 0.7;
    g.fillStyle = flash ? '#ffffff' : '#050000'; g.fillRect(0, 0, w, h);
    const s = 0.4 + 1.2 * Math.pow(Math.min(1, p * 1.7), 0.5);     // zooms in fast
    const cx = w / 2 + (Math.random() - 0.5) * w * 0.03, cy = h / 2 + (Math.random() - 0.5) * h * 0.03;
    const R = Math.min(w, h) * 0.5 * s;

    const glow = g.createRadialGradient(cx, cy, R * 0.2, cx, cy, R * 1.9);
    glow.addColorStop(0, 'rgba(170,0,25,0.75)'); glow.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = glow; g.fillRect(0, 0, w, h);

    g.strokeStyle = '#120a0a'; g.lineWidth = Math.max(1, R * 0.02);   // hanging hair
    for (let i = 0; i < 26; i++) {
      const x = cx + (i / 25 - 0.5) * R * 1.9;
      g.beginPath(); g.moveTo(x, cy - R);
      g.quadraticCurveTo(x + (Math.random() - 0.5) * R * 0.2, cy, x + (Math.random() - 0.5) * R * 0.3, cy + R * (0.9 + Math.random() * 0.5));
      g.stroke();
    }

    const hg = g.createRadialGradient(cx - R * 0.15, cy - R * 0.2, R * 0.1, cx, cy, R * 1.05);
    hg.addColorStop(0, '#e4dad0'); hg.addColorStop(1, '#5e504c');   // pale, gaunt head
    g.fillStyle = hg; g.beginPath(); g.ellipse(cx, cy, R * 0.78, R, 0, 0, Math.PI * 2); g.fill();

    g.strokeStyle = 'rgba(120,20,30,0.55)'; g.lineWidth = Math.max(1, R * 0.012);   // veins
    for (let i = 0; i < 9; i++) {
      const a = Math.random() * Math.PI * 2;
      g.beginPath(); g.moveTo(cx + Math.cos(a) * R * 0.76, cy + Math.sin(a) * R * 0.96);
      g.lineTo(cx + Math.cos(a) * R * 0.45 + (Math.random() - 0.5) * R * 0.1, cy + Math.sin(a) * R * 0.55); g.stroke();
    }

    g.fillStyle = '#050000';                                        // empty sockets: it is blind
    for (const side of [-1, 1]) { g.beginPath(); g.ellipse(cx + side * R * 0.3, cy - R * 0.2, R * 0.17, R * 0.11, side * 0.25, 0, Math.PI * 2); g.fill(); }

    const my = cy + R * 0.45, rx = R * 0.46, ry = R * (0.3 + 0.07 * Math.sin(p * 70));   // mouth shaking open
    g.fillStyle = '#0a0000'; g.beginPath(); g.ellipse(cx, my, rx, ry, 0, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#5a0010'; g.beginPath(); g.ellipse(cx, my + ry * 0.2, rx * 0.7, ry * 0.55, 0, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#e8e0cf';                                        // jagged teeth top + bottom
    const tw = (rx * 1.7) / 9;
    for (let i = 0; i < 9; i++) {
      const x0 = cx - rx * 0.85 + i * tw, len = ry * (0.45 + 0.25 * ((i * 7) % 3) / 2);
      g.beginPath(); g.moveTo(x0, my - ry * 0.85); g.lineTo(x0 + tw, my - ry * 0.85); g.lineTo(x0 + tw / 2, my - ry * 0.85 + len); g.fill();
      g.beginPath(); g.moveTo(x0, my + ry * 0.85); g.lineTo(x0 + tw, my + ry * 0.85); g.lineTo(x0 + tw / 2, my + ry * 0.85 - len); g.fill();
    }

    for (let i = 0; i < 5; i++) {                                   // glitch bars
      g.fillStyle = Math.random() < 0.5 ? 'rgba(255,0,60,0.25)' : 'rgba(0,255,255,0.15)';
      g.fillRect(0, Math.random() * h, w, 2 + Math.random() * h * 0.04);
    }
  }

  drawRings(ctx, cam) {
    for (const g of this.rings) {
      ctx.strokeStyle = `rgba(255,40,60,${1 - g.r / g.maxR})`; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.arc(g.x - cam.x, g.y - cam.y, g.r, 0, Math.PI * 2); ctx.stroke();
    }
  }
}
