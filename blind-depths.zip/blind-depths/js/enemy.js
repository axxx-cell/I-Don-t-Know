'use strict';
/* ==========================================================
   enemy.js - The Blind Stalker.
   It has NO eyes. It reacts to two things only:
     1) the flashlight beam touching its body  -> targets the player
     2) a sound ripple ring touching its body  -> targets where the sound began
   States: patrol -> windup (screech) -> charge -> search -> patrol
   `aggr` (1.0+) scales speed; game.js raises it over time and depth.
   ========================================================== */

class Stalker {
  constructor(x, y) {
    this.x = x; this.y = y; this.r = 13;
    this.state = 'patrol';
    this.timer = 0;             // used by windup / search / patrol pause
    this.path = []; this.pi = 0; this.repath = 0;
    this.target = null;         // last known location it is heading to
    this.inBeam = false;        // read by game.js (camera shake + flicker)
    this.screeched = false;     // one-frame event flag for game.js (sound)
    this.rings = [];            // screech rings (drawn above the darkness)
    this.facing = 0;
    this.patrolSpeed = 70;
    this.chargeSpeed = 185;     // player walks at 150, so running in the open fails
  }

  /** Distance to a point. */
  distTo(p) { return Math.hypot(p.x - this.x, p.y - this.y); }

  update(dt, player, map, aggr = 1) {
    this.screeched = false;

    // ----- SENSES -----
    this.inBeam = player.isInBeam(this.x, this.y, this.r, map);
    const ripple = player.rippleTouches(this.x, this.y, this.r);
    let stimulus = null;
    if (this.inBeam) stimulus = { x: player.x, y: player.y };      // sees the light: knows exactly where you are
    else if (ripple) stimulus = { x: ripple.x, y: ripple.y };      // heard noise: goes to where it began

    if (stimulus) {
      this.target = stimulus;
      if (this.state === 'patrol' || this.state === 'search') {
        this.state = 'windup'; this.timer = 0.4; this.path = [];   // short screech before the charge
        this.screech();
      } else if (this.state === 'charge') {
        this.repath = Math.min(this.repath, 0.1);                  // fresh stimulus: re-plan soon
      }
    }

    // ----- STATE MACHINE -----
    switch (this.state) {
      case 'windup':
        this.timer -= dt;
        if (this.target) this.facing = Math.atan2(this.target.y - this.y, this.target.x - this.x);
        if (this.timer <= 0) { this.state = 'charge'; this.repath = 0; }
        break;
      case 'charge': this.chase(dt, map, aggr); break;
      case 'search':
        this.timer -= dt; this.facing += dt * 2.2;                 // sweeps its head, listening
        if (this.timer <= 0) { this.state = 'patrol'; this.path = []; }
        break;
      default: this.patrol(dt, map, aggr);
    }

    // ----- screech rings -----
    for (const g of this.rings) g.r += g.speed * dt;
    this.rings = this.rings.filter(g => g.r < g.maxR);
  }

  patrol(dt, map, aggr) {
    if (this.timer > 0) { this.timer -= dt; return; }              // brief pause at each stop
    if (this.pi >= this.path.length) {
      const p = map.randomFloorPoint();
      this.setPath(map.findPath(this.x, this.y, p.x, p.y));
      this.timer = 0.6;
      return;
    }
    this.followPath(dt, this.patrolSpeed * aggr, map);
  }

  chase(dt, map, aggr) {
    this.repath -= dt;
    if (this.repath <= 0 || !this.path.length) {
      const p = map.findPath(this.x, this.y, this.target.x, this.target.y);
      p.push({ x: this.target.x, y: this.target.y });              // finish on the exact spot
      this.setPath(p); this.repath = 0.3;
    }
    const done = this.followPath(dt, this.chargeSpeed * aggr, map);
    if (done || this.distTo(this.target) < 16) {                   // reached it, nothing new heard
      this.state = 'search'; this.timer = 2.5; this.path = [];
    }
  }

  /**
   * Adopt a new path. If we are already past the first tile centre (between it
   * and the second), skip it - otherwise every re-plan would drag us backwards.
   */
  setPath(p) {
    this.path = p; this.pi = 0;
    if (p.length > 1) {
      const a = p[0], b = p[1];
      if (Math.hypot(a.x - this.x, a.y - this.y) < 6 ||
          Math.hypot(b.x - this.x, b.y - this.y) < Math.hypot(b.x - a.x, b.y - a.y)) this.pi = 1;
    }
  }

  /** Walk toward the current waypoint. Returns true when the path is finished. */
  followPath(dt, speed, map) {
    if (this.pi >= this.path.length) return true;
    const w = this.path[this.pi];
    const dx = w.x - this.x, dy = w.y - this.y, d = Math.hypot(dx, dy), step = speed * dt;
    if (d <= step) { this.x = w.x; this.y = w.y; this.pi++; }
    else { map.moveCircle(this, (dx / d) * step, (dy / d) * step, this.r * 0.8); this.facing = Math.atan2(dy, dx); }
    return this.pi >= this.path.length;
  }

  /** Emit a red ring so the player learns where it is (even in the dark). */
  screech() {
    this.rings.push({ x: this.x, y: this.y, r: 10, maxR: 340, speed: 420 });
    this.screeched = true;
  }

  /* ---------- RENDERING ---------- */
  /** Body is drawn BEFORE the darkness layer, so it only shows inside the beam. */
  draw(ctx, cam, t) {
    const hot = this.state === 'charge' || this.state === 'windup';
    ctx.save();
    ctx.translate(this.x - cam.x, this.y - cam.y); ctx.rotate(this.facing);
    ctx.fillStyle = hot ? '#9b1226' : '#4d1b25';
    ctx.beginPath();
    for (let i = 0; i < 14; i++) {                                 // jagged, twitching silhouette
      const a = (i / 14) * Math.PI * 2;
      const rad = this.r * (i % 2 ? 0.8 : 1.35) + Math.sin(t * (hot ? 22 : 6) + i * 1.7) * (hot ? 3 : 1);
      i ? ctx.lineTo(Math.cos(a) * rad, Math.sin(a) * rad) : ctx.moveTo(Math.cos(a) * rad, Math.sin(a) * rad);
    }
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#d9cccc';                                     // pale smooth face: no eyes
    ctx.beginPath(); ctx.arc(5, 0, 6, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  drawRings(ctx, cam) {
    for (const g of this.rings) {
      ctx.strokeStyle = `rgba(255,40,60,${1 - g.r / g.maxR})`; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.arc(g.x - cam.x, g.y - cam.y, g.r, 0, Math.PI * 2); ctx.stroke();
    }
  }
}
