'use strict';
/* ==========================================================
   player.js - Movement, flashlight, footstep ripples, looting.
   - WASD/arrows move, SHIFT = sneak (quieter, slower)
   - Flashlight cone shrinks as the battery drains
   - Ripples = visible sound waves (the enemy "hears" them)
   - Hold E near a loot box to fill the progress ring
   ========================================================== */

// Item catalogue. `weight` = chance to drop from a loot box.
const ITEMS = {
  battery: { id: 'battery', label: 'BAT', name: 'Battery',        weight: 35 },
  scrap:   { id: 'scrap',   label: 'SCR', name: 'Scrap Metal',    weight: 45 },
  drive:   { id: 'drive',   label: 'DRV', name: 'Cryptic Drive',  weight: 20 }
};

// Flashlight tuning (full battery -> empty battery)
const LIGHT = { maxR: 430, minR: 115, maxHalf: 0.6, minHalf: 0.24 };
// How dark the unlit world is: 1 = pitch black, lower = you can faintly see the map. Tweak me!
const DARK_ALPHA = 0.86; // half-angle in radians

class Player {
  constructor(x, y, drainRate = 1.8) {
    this.x = x; this.y = y; this.radius = 10;
    this.angle = 0;                 // facing direction (toward mouse)
    this.walkSpeed = 150; this.sneakSpeed = 75;
    this.moving = false; this.sneaking = false;

    this.battery = 100;             // percent
    this.drainRate = drainRate;     // percent per second (upgraded in the terminal)
    this.lightR = LIGHT.maxR;       // current (smoothed) light radius
    this.lightHalf = LIGHT.maxHalf; // current (smoothed) half-angle
    this.intensity = 1;             // 0..1 brightness (flicker lowers it)
    this.panic = false;             // set by game.js when the stalker is in the beam

    this.inventory = []; this.maxSlots = 12;
    this.ripScale = 1;              // quiet-boots upgrade lowers this
    this.ripples = []; this.stepAccum = 0;

    // Loot interaction state
    this.interact = { target: null, progress: 0, duration: 1.6 };

    // Offscreen canvas used to build the darkness mask
    this.dark = document.createElement('canvas');
    this.dctx = this.dark.getContext('2d');
  }

  /** Put the player back at the elevator for a new run (keeps upgrades). */
  respawn(x, y) {
    this.x = x; this.y = y; this.battery = 100;
    this.inventory = []; this.ripples = []; this.stepAccum = 0;
    this.interact.target = null; this.interact.progress = 0;
    this.panic = false; this.intensity = 1;
  }

  /**
   * Per-frame update.
   * @param dt seconds since last frame
   * @param input {keys:Set, mouse:{x,y} (world coords)}
   * @returns {object|null} event: {type:'loot', item} | {type:'full'} | null
   */
  update(dt, input, map) {
    const k = input.keys;
    this.mapRef = map; // kept for drawDarkness() raycasts
    // ----- aim -----
    this.angle = Math.atan2(input.mouse.y - this.y, input.mouse.x - this.x);

    // ----- movement -----
    let mx = (k.has('d') || k.has('arrowright') ? 1 : 0) - (k.has('a') || k.has('arrowleft') ? 1 : 0);
    let my = (k.has('s') || k.has('arrowdown') ? 1 : 0) - (k.has('w') || k.has('arrowup') ? 1 : 0);
    this.sneaking = k.has('shift');
    this.moving = mx !== 0 || my !== 0;
    if (this.moving) {
      this.walkT = (this.walkT || 0) + dt * (this.sneaking ? 7 : 12);   // walk-cycle animation clock
      const len = Math.hypot(mx, my); mx /= len; my /= len;       // normalise diagonals
      const sp = (this.sneaking ? this.sneakSpeed : this.walkSpeed) * dt;
      const sx = this.x, sy = this.y;
      map.moveCircle(this, mx * sp, my * sp, this.radius);
      this.stepAccum += Math.hypot(this.x - sx, this.y - sy);
      // Emit a footstep ripple every N pixels walked (sneaking = rarer & smaller)
      const stride = this.sneaking ? 60 : 38;
      if (this.stepAccum >= stride) { this.stepAccum = 0; this.emitRipple(map); }
    }

    // ----- battery & flashlight smoothing -----
    this.battery = Math.max(0, this.battery - this.drainRate * dt);
    const f = Math.pow(this.battery / 100, 0.8);
    const tR = LIGHT.minR + (LIGHT.maxR - LIGHT.minR) * f;
    const tH = LIGHT.minHalf + (LIGHT.maxHalf - LIGHT.minHalf) * f;
    const s = Math.min(1, dt * 3);                    // smooth approach
    this.lightR += (tR - this.lightR) * s;
    this.lightHalf += (tH - this.lightHalf) * s;

    // ----- flicker (panic) -----
    if (this.panic) this.intensity = Math.random() < 0.45 ? Math.random() * 0.4 : 1;
    else this.intensity += (1 - this.intensity) * Math.min(1, dt * 8);

    // ----- ripples -----
    for (const r of this.ripples) r.r += r.speed * dt;
    this.ripples = this.ripples.filter(r => r.r < r.maxR);

    // ----- looting -----
    return this.updateInteract(dt, k, map);
  }

  /** Create one expanding sound ring. Glass doubles the size. */
  emitRipple(map) {
    const glass = map.isGlassAt(this.x, this.y);
    const load = (1 + 0.08 * this.inventory.length) * this.ripScale; // greed: heavier haul = louder
    const base = this.sneaking ? 45 : 110;                // normal footstep size
    const maxR = (glass ? 220 : base) * load;             // glass = 2x normal walking size
    this.ripples.push({ x: this.x, y: this.y, r: 6, maxR, speed: 160, glass });
  }

  /** Hold E next to a loot box to fill the ring; complete = random item. */
  updateInteract(dt, keys, map) {
    const it = this.interact;
    // nearest unlooted box within reach
    let near = null, best = 58;
    for (const l of map.loot) {
      if (l.looted) continue;
      const d = Math.hypot(l.x - this.x, l.y - this.y);
      if (d < best) { best = d; near = l; }
    }
    this.nearLoot = near; // lets the game show an "[E] LOOT" prompt
    if (near && keys.has('e') && !this.moving) {
      if (it.target !== near) { it.target = near; it.progress = 0; }
      it.progress += dt / it.duration;
      if (it.progress >= 1) {
        it.progress = 0; it.target = null;
        if (this.inventory.length >= this.maxSlots) return { type: 'full' };
        near.looted = true;
        const item = this.rollItem();
        this.inventory.push(item.id);
        return { type: 'loot', item };
      }
    } else {
      // released / walked away: ring drains back quickly
      it.progress = Math.max(0, it.progress - dt * 2.5);
      if (it.progress === 0) it.target = near && keys.has('e') ? near : null;
    }
    this.nearLoot = near; // lets the game show an "[E] LOOT" prompt
    return null;
  }

  /** Weighted random pick from ITEMS. */
  rollItem() {
    const list = Object.values(ITEMS);
    let roll = Math.random() * list.reduce((a, b) => a + b.weight, 0);
    for (const item of list) { roll -= item.weight; if (roll <= 0) return item; }
    return list[0];
  }

  /**
   * F: throw a Scrap Metal along the aim line (stops at walls). It makes a
   * loud amber ripple there - the stalker charges at the noise, not at you.
   * Returns the landing point or null if no scrap is carried.
   */
  throwDecoy(map) {
    const i = this.inventory.indexOf('scrap');
    if (i < 0) return null;
    this.inventory.splice(i, 1);
    const d = Math.max(30, map.raycast(this.x, this.y, this.angle, 320) - 14);
    const x = this.x + Math.cos(this.angle) * d, y = this.y + Math.sin(this.angle) * d;
    this.ripples.push({ x, y, r: 6, maxR: 210, speed: 230, glass: false, decoy: true });
    return { x, y };
  }

  /** Q: consume a battery item to recharge the flashlight. */
  useBattery() {
    const i = this.inventory.indexOf('battery');
    if (i < 0 || this.battery >= 100) return false;
    this.inventory.splice(i, 1);
    this.battery = Math.min(100, this.battery + 40);
    return true;
  }

  /* ---------- QUERIES FOR THE ENEMY ---------- */
  /** Is a point inside the lit cone (range, angle AND line of sight)? */
  isInBeam(px, py, pad, map) {
    const dx = px - this.x, dy = py - this.y;
    const d = Math.hypot(dx, dy);
    if (d > this.lightR + pad) return false;
    let diff = Math.atan2(dy, dx) - this.angle;
    diff = Math.atan2(Math.sin(diff), Math.cos(diff));       // wrap to -PI..PI
    const slack = d > 1 ? Math.atan2(pad, d) : Math.PI;      // account for body size
    if (Math.abs(diff) > this.lightHalf + slack) return false;
    return map.hasLineOfSight(this.x, this.y, px, py);
  }
  /** Does a point touch the edge of any live ripple ring? */
  rippleTouches(px, py, pad) {
    for (const r of this.ripples) {
      const d = Math.hypot(px - r.x, py - r.y);
      if (Math.abs(d - r.r) < pad + 8) return r; // caller uses r.x/r.y as where the sound came from
    }
    return null;
  }

  /* ---------- RENDERING ---------- */
  /** Top-down survivor: breathing/walking animation, rim light, bandana, scarf, glowing flashlight. */
  drawBody(ctx, cam) {
    const t = Date.now() / 1000;
    const sw = this.moving ? Math.sin(this.walkT || 0) : 0;          // walk swing -1..1
    const bob = this.moving ? Math.abs(sw) * 1.3 : Math.sin(t * 2) * 0.5;   // head bob / breathing
    const sc = this.sneaking ? 1.15 : 1.3;                           // crouch a little when sneaking
    ctx.save();
    ctx.translate(this.x - cam.x, this.y - cam.y);
    ctx.fillStyle = 'rgba(0,0,0,0.45)';                              // ground shadow
    ctx.beginPath(); ctx.ellipse(0, 4, 16 * sc / 1.3, 13 * sc / 1.3, 0, 0, Math.PI * 2); ctx.fill();
    ctx.rotate(this.angle); ctx.scale(sc, sc);                       // from here +x = facing direction

    // bandana tails flutter behind the head
    const fl = Math.sin(t * 9 + (this.walkT || 0)) * (this.moving ? 3 : 1);
    ctx.strokeStyle = '#ff4f6d'; ctx.lineWidth = 2.4; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(-5, -1.5); ctx.quadraticCurveTo(-11, -3 + fl, -17, -5 + fl * 1.4); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(-5, 1.5); ctx.quadraticCurveTo(-11, 3 - fl, -16, 5 - fl * 1.2); ctx.stroke();

    // boots (swing front/back), with soles
    for (const side of [-1, 1]) {
      const fx = -2 + sw * 6 * side;
      ctx.fillStyle = '#2a2a38'; ctx.beginPath(); ctx.ellipse(fx, side * 6, 5.8, 3.5, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#5a5a74'; ctx.beginPath(); ctx.ellipse(fx + 3, side * 6, 2.2, 2.6, 0, 0, Math.PI * 2); ctx.fill();
    }

    // backpack with straps and a blinking LED
    ctx.fillStyle = '#e0702e'; ctx.fillRect(-15, -7.5, 9, 15);
    ctx.fillStyle = '#b5521d'; ctx.fillRect(-15, -1, 9, 2); ctx.fillRect(-13, -7.5, 2, 15);
    ctx.fillStyle = Math.sin(t * 5) > 0 ? '#ff3040' : '#501018';
    ctx.beginPath(); ctx.arc(-14, 0, 1.5, 0, Math.PI * 2); ctx.fill();

    // jacket with cyan rim light and reflective stripe
    ctx.shadowColor = 'rgba(90,210,255,0.75)'; ctx.shadowBlur = 9;
    ctx.fillStyle = '#3d8bf0'; ctx.beginPath(); ctx.ellipse(0, 0, 8.5, 13.5, 0, 0, Math.PI * 2); ctx.fill();
    ctx.shadowBlur = 0;
    ctx.strokeStyle = '#2459a8'; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.strokeStyle = 'rgba(255,224,102,0.9)'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(-2, -11); ctx.lineTo(-2, 11); ctx.stroke();

    // scarf around the neck
    ctx.strokeStyle = '#ff9a3c'; ctx.lineWidth = 3.5;
    ctx.beginPath(); ctx.ellipse(1.5, 0, 6.8, 8.6, 0, 0, Math.PI * 2); ctx.stroke();

    // arms: left swings, right holds the flashlight forward (dark gloves)
    ctx.strokeStyle = '#3272c9'; ctx.lineWidth = 5;
    ctx.beginPath(); ctx.moveTo(1, -11); ctx.lineTo(5 + sw * 2.5, -13); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(1, 11); ctx.lineTo(15, 8); ctx.stroke();
    ctx.fillStyle = '#2b2f3a';
    ctx.beginPath(); ctx.arc(6 + sw * 2.5, -13.5, 3, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(16, 8, 3, 0, Math.PI * 2); ctx.fill();

    // flashlight + glowing lens (dead = grey)
    ctx.fillStyle = '#c4ccd8'; ctx.fillRect(14, 5.5, 11, 5);
    ctx.fillStyle = '#3a3f4c'; ctx.fillRect(14, 6.5, 4, 3);
    if (this.battery > 0) {
      const lg = ctx.createRadialGradient(27, 8, 0, 27, 8, 11);
      lg.addColorStop(0, `rgba(255,244,170,${0.9 * this.intensity})`); lg.addColorStop(1, 'rgba(255,244,170,0)');
      ctx.fillStyle = lg; ctx.fillRect(16, -3, 22, 22);
    }
    ctx.fillStyle = this.battery > 0 ? '#fff6b0' : '#555'; ctx.fillRect(24, 4.5, 3, 7);

    // head (bobs), ears, hair, headband, nose
    ctx.translate(bob * 0.35, 0);
    ctx.fillStyle = '#f0c8a0';
    ctx.beginPath(); ctx.arc(1.5, -7.4, 2.2, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(1.5, 7.4, 2.2, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(1.5, 0, 7.6, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#2b1b12'; ctx.beginPath(); ctx.arc(1.5, 0, 8, Math.PI * 0.42, Math.PI * 1.58); ctx.closePath(); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.18)'; ctx.beginPath(); ctx.arc(-1, -3, 2.6, 0, Math.PI * 2); ctx.fill();   // hair shine
    ctx.strokeStyle = '#ff4f6d'; ctx.lineWidth = 2.6;
    ctx.beginPath(); ctx.arc(1.5, 0, 7.2, -0.95, 0.95); ctx.stroke();
    ctx.fillStyle = '#f0c8a0'; ctx.beginPath(); ctx.arc(9.2, 0, 1.7, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  /**
   * Build the darkness layer: fill black, then "erase" the flashlight cone
   * (polygon built from wall-clipped rays) with a fading radial gradient,
   * plus a tiny halo so the player is never fully blind. One drawImage.
   */
  drawDarkness(ctx, cam, w, h) {
    if (this.dark.width !== w || this.dark.height !== h) { this.dark.width = w; this.dark.height = h; }
    const d = this.dctx, sx = this.x - cam.x, sy = this.y - cam.y;
    d.globalCompositeOperation = 'source-over'; d.globalAlpha = 1;
    d.fillStyle = 'rgba(0,0,0,' + DARK_ALPHA + ')'; d.fillRect(0, 0, w, h);
    d.globalCompositeOperation = 'destination-out';

    // --- flashlight cone ---
    const I = this.intensity, R = this.lightR, rays = 80;
    const a0 = this.angle - this.lightHalf, span = this.lightHalf * 2;
    const pts = [];                                    // cone outline, reused for the warm light tint
    d.beginPath(); d.moveTo(sx, sy);
    for (let i = 0; i <= rays; i++) {
      const a = a0 + span * (i / rays);
      const dist = this.lightR > 0 ? this.mapRef.raycast(this.x, this.y, a, R) : 0;
      const px = sx + Math.cos(a) * dist, py = sy + Math.sin(a) * dist;
      pts.push([px, py]); d.lineTo(px, py);
    }
    this.conePts = pts;
    d.closePath();
    const g = d.createRadialGradient(sx, sy, 0, sx, sy, R);
    g.addColorStop(0, `rgba(0,0,0,${I})`);
    g.addColorStop(0.7, `rgba(0,0,0,${I * 0.92})`);
    g.addColorStop(1, 'rgba(0,0,0,0)');
    d.fillStyle = g; d.fill();

    // --- faint ambient halo (also wall-clipped) ---
    const HR = 130; d.beginPath();
    for (let i = 0; i < 28; i++) {
      const a = (i / 28) * Math.PI * 2, dist = this.mapRef.raycast(this.x, this.y, a, HR);
      const px = sx + Math.cos(a) * dist, py = sy + Math.sin(a) * dist;
      i ? d.lineTo(px, py) : d.moveTo(px, py);
    }
    d.closePath();
    const hg = d.createRadialGradient(sx, sy, 0, sx, sy, HR);
    hg.addColorStop(0, 'rgba(0,0,0,0.9)'); hg.addColorStop(1, 'rgba(0,0,0,0)');
    d.fillStyle = hg; d.fill();

    ctx.drawImage(this.dark, 0, 0);
  }

  /** Warm golden glow inside the beam (additive), so the light has colour, not just brightness. */
  drawLightTint(ctx, cam) {
    if (!this.conePts) return;
    const sx = this.x - cam.x, sy = this.y - cam.y;
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    ctx.beginPath(); ctx.moveTo(sx, sy);
    for (const p of this.conePts) ctx.lineTo(p[0], p[1]);
    ctx.closePath();
    const g = ctx.createRadialGradient(sx, sy, 0, sx, sy, this.lightR);
    g.addColorStop(0, `rgba(255,214,140,${0.26 * this.intensity})`); g.addColorStop(1, 'rgba(255,214,140,0)');
    ctx.fillStyle = g; ctx.fill(); ctx.restore();
  }

  /** Sound-wave rings. Drawn AFTER darkness so you can always see your own noise. */
  drawRipples(ctx, cam) {
    for (const r of this.ripples) {
      const a = 1 - r.r / r.maxR;
      ctx.strokeStyle = r.decoy ? `rgba(255,200,87,${a * 0.9})`
        : r.glass ? `rgba(255,120,120,${a * 0.9})` : `rgba(77,232,255,${a * 0.6})`;
      ctx.lineWidth = r.glass ? 3 : 2;
      ctx.beginPath(); ctx.arc(r.x - cam.x, r.y - cam.y, r.r, 0, Math.PI * 2); ctx.stroke();
    }
  }

  /** Circular loading ring around the loot box being opened. */
  drawInteract(ctx, cam) {
    const t = this.interact.target;
    if (t && this.interact.progress > 0) {
      const x = t.x - cam.x, y = t.y - cam.y;
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(255,255,255,0.15)';
      ctx.beginPath(); ctx.arc(x, y, 24, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = '#ffc857';
      ctx.beginPath(); ctx.arc(x, y, 24, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * this.interact.progress); ctx.stroke();
    }
  }
}
