'use strict';
/* ==========================================================
   touch.js - On-screen controls for phones/tablets.
   - LEFT thumb  : floating move stick (light push = SNEAK, full push = walk)
   - RIGHT thumb : floating aim stick (drag to point the flashlight)
   - Buttons     : LOOT (hold), THROW (tap), BATT (tap)
   It does not touch the game internals: it fires the same keyboard
   events the game already listens for, and sets window.GameAim
   (read by game.js) to aim the flashlight.
   Does nothing on non-touch devices.
   ========================================================== */
(() => {
  const isTouch = ('ontouchstart' in window) || navigator.maxTouchPoints > 0 ||
                  (window.matchMedia && matchMedia('(pointer: coarse)').matches);
  if (!isTouch) return;

  // Shared aim vector (unit length). game.js uses it once `active` is true.
  window.GameAim = window.GameAim || { x: 1, y: 0, active: false };
  const aim = window.GameAim;

  /* ---------- fake keyboard ---------- */
  const fire = (k, down) => window.dispatchEvent(new KeyboardEvent(down ? 'keydown' : 'keyup', { key: k }));
  const held = new Set();
  function hold(k, on) {                       // only fire on changes
    if (on && !held.has(k)) { held.add(k); fire(k, true); }
    else if (!on && held.has(k)) { held.delete(k); fire(k, false); }
  }
  const tap = k => { fire(k, true); fire(k, false); };

  /* ---------- build the DOM ---------- */
  const layer = document.createElement('div');
  layer.id = 'touch-layer';
  layer.innerHTML =
    '<div id="stick-l" class="stick"><div class="knob"></div></div>' +
    '<div id="stick-r" class="stick"><div class="knob"></div></div>' +
    '<div class="tbtn" id="t-loot">LOOT</div>' +
    '<div class="tbtn small" id="t-throw">THROW</div>' +
    '<div class="tbtn small" id="t-bat">BATT</div>';
  document.body.appendChild(layer);
  const $ = id => document.getElementById(id);
  const stickEl = { l: $('stick-l'), r: $('stick-r') };

  // Hide the keyboard hint, add touch help + fullscreen button to the start screen
  $('hint').style.display = 'none';
  const help = document.createElement('p');
  help.className = 'body';
  help.innerHTML = 'LEFT thumb: move (light push = sneak)<br>RIGHT thumb: aim flashlight<br>Buttons: LOOT (hold) &middot; THROW scrap &middot; BATT';
  $('start-screen').insertBefore(help, $('start-btn'));
  const fsBtn = document.createElement('button');
  fsBtn.textContent = '[ FULLSCREEN + LANDSCAPE ]';
  fsBtn.onclick = async () => {
    try { await document.documentElement.requestFullscreen(); } catch (e) { /* not supported */ }
    try { await screen.orientation.lock('landscape'); } catch (e) { /* not supported */ }
  };
  $('start-screen').appendChild(fsBtn);
  const rot = document.createElement('div');
  rot.id = 'rotate-warn'; rot.textContent = 'ROTATE YOUR PHONE TO LANDSCAPE';
  document.body.appendChild(rot);

  /* ---------- floating sticks ---------- */
  const R = 60;                       // stick radius in px
  const sticks = {};                  // pointerId -> {side, ox, oy}
  let moveDir = null;                 // last move direction (flashlight follows it when not aiming)

  const sideActive = s => Object.values(sticks).some(t => t.side === s);

  function showStick(side, x, y) {
    const el = stickEl[side];
    el.style.display = 'block'; el.style.left = x + 'px'; el.style.top = y + 'px';
    el.firstChild.style.transform = 'translate(0,0)';
  }

  layer.addEventListener('pointerdown', e => {
    if (e.target.closest('.tbtn')) return;                 // buttons handle themselves
    e.preventDefault();
    const side = e.clientX < window.innerWidth / 2 ? 'l' : 'r';
    if (sideActive(side)) return;                          // one finger per stick
    sticks[e.pointerId] = { side, ox: e.clientX, oy: e.clientY };
    layer.setPointerCapture(e.pointerId);
    showStick(side, e.clientX, e.clientY);
    aim.active = true;
  });

  layer.addEventListener('pointermove', e => {
    const s = sticks[e.pointerId];
    if (!s) return;
    e.preventDefault();
    let dx = e.clientX - s.ox, dy = e.clientY - s.oy;
    const len = Math.hypot(dx, dy) || 1;
    const mag = Math.min(1, len / R);
    const nx = dx / len, ny = dy / len;
    const kx = nx * Math.min(len, R), ky = ny * Math.min(len, R);
    stickEl[s.side].firstChild.style.transform = `translate(${kx}px,${ky}px)`;

    if (s.side === 'l') {
      const on = mag > 0.22;                               // dead zone
      hold('d', on && nx > 0.38); hold('a', on && nx < -0.38);
      hold('s', on && ny > 0.38); hold('w', on && ny < -0.38);
      hold('shift', on && mag < 0.62);                     // gentle push = sneak (quiet)
      moveDir = on ? { x: nx, y: ny } : null;
      if (moveDir && !sideActive('r')) { aim.x = nx; aim.y = ny; }
    } else if (len > 8) {
      aim.x = nx; aim.y = ny;                              // aim stick overrides
    }
  });

  function release(e) {
    const s = sticks[e.pointerId];
    if (!s) return;
    delete sticks[e.pointerId];
    stickEl[s.side].style.display = 'none';
    if (s.side === 'l') { ['w', 'a', 's', 'd', 'shift'].forEach(k => hold(k, false)); moveDir = null; }
  }
  layer.addEventListener('pointerup', release);
  layer.addEventListener('pointercancel', release);

  /* ---------- buttons ---------- */
  function bindButton(id, onDown, onUp) {
    const el = $(id);
    el.addEventListener('pointerdown', e => {
      e.preventDefault(); e.stopPropagation();
      el.setPointerCapture(e.pointerId); el.classList.add('down'); onDown();
    });
    const up = () => { el.classList.remove('down'); if (onUp) onUp(); };
    el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
  }
  bindButton('t-loot', () => hold('e', true), () => hold('e', false));   // hold to search
  bindButton('t-throw', () => tap('f'));
  bindButton('t-bat', () => tap('q'));

  /* ---------- show controls only during a run ---------- */
  setInterval(() => {
    const playing = !$('hud').classList.contains('hidden');
    layer.style.display = playing ? 'block' : 'none';
    if (!playing) {                                        // release everything between runs
      [...held].forEach(k => hold(k, false));
      for (const id in sticks) delete sticks[id];
      stickEl.l.style.display = stickEl.r.style.display = 'none';
    }
  }, 150);

  // Block the browser context menu / long-press selection while playing
  window.addEventListener('contextmenu', e => e.preventDefault());
})();
