'use strict';
/* ==========================================================
   audio.js - Procedural horror sound using the Web Audio API.
   No audio files: every sound is synthesised, so the ZIP stays tiny.
   game.js calls these through window.Sfx (and ignores errors).
   Press M to mute / unmute.
   Browsers only allow audio after a tap/click, so Sfx.init() is
   called from the DESCEND / DEPLOY buttons.
   ========================================================== */
(() => {
  const AC = window.AudioContext || window.webkitAudioContext;
  let ac = null, master = null, noiseBuf = null, muted = false;
  let nextBeat = 0;                          // heartbeat scheduler

  /** Create the audio graph once (must follow a user gesture). */
  function init() {
    if (!AC) return;
    if (ac) { if (ac.state === 'suspended') ac.resume(); return; }
    ac = new AC();
    master = ac.createGain(); master.gain.value = muted ? 0 : 0.7; master.connect(ac.destination);

    // 1 second of white noise, reused by footsteps / glass / screech
    noiseBuf = ac.createBuffer(1, ac.sampleRate, ac.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;

    startDrone();
  }

  /** Low, slowly breathing ambient hum under everything. */
  function startDrone() {
    const g = ac.createGain(); g.gain.value = 0.05;
    const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 140;
    [43, 45.2, 64.5].forEach(f => {
      const o = ac.createOscillator(); o.type = 'sawtooth'; o.frequency.value = f;
      o.connect(lp); o.start();
    });
    lp.connect(g); g.connect(master);
    const lfo = ac.createOscillator(), lg = ac.createGain();   // slow volume swell
    lfo.frequency.value = 0.08; lg.gain.value = 0.025;
    lfo.connect(lg); lg.connect(g.gain); lfo.start();
  }

  /* ---------- helpers ---------- */
  /** Short noise burst through one filter with a fast decay envelope. */
  function noise(type, freq, vol, dur, when = 0, q = 1) {
    const t = ac.currentTime + when;
    const s = ac.createBufferSource(); s.buffer = noiseBuf;
    const f = ac.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
    const g = ac.createGain();
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(master);
    s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.02);
  }
  /** Oscillator tone with optional pitch glide. */
  function tone(type, f0, f1, vol, dur, when = 0) {
    const t = ac.currentTime + when;
    const o = ac.createOscillator(), g = ac.createGain();
    o.type = type; o.frequency.setValueAtTime(f0, t);
    if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(f1, t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + dur + 0.02);
  }

  /* ---------- public sounds ---------- */
  const Sfx = {
    init,

    /** Footstep. Glass = bright crunchy shards; sneaking = soft. */
    step(glass, sneaking) {
      if (!ac) return;
      if (glass) {
        for (let i = 0; i < 4; i++) noise('highpass', 3500 + Math.random() * 2500, 0.16, 0.07, i * 0.025);
        noise('bandpass', 900, 0.1, 0.1);
      } else {
        noise('bandpass', sneaking ? 220 : 340, sneaking ? 0.05 : 0.13, sneaking ? 0.08 : 0.11, 0, 1.5);
      }
    },

    /** The stalker spots / hears you. */
    screech() {
      if (!ac) return;
      tone('sawtooth', 700, 2400, 0.16, 0.55);
      tone('square', 1100, 3200, 0.07, 0.45);
      noise('bandpass', 2500, 0.22, 0.6, 0, 3);
    },

    /** Heartbeat. Called every frame with proximity 0..1 (0 = silent). */
    pulse(prox) {
      if (!ac || prox < 0.06) { nextBeat = 0; return; }
      const now = ac.currentTime;
      if (now < nextBeat) return;
      const v = 0.12 + prox * 0.4;
      tone('sine', 70, 40, v, 0.16);                // lub
      tone('sine', 60, 35, v * 0.8, 0.18, 0.17);    // dub
      nextBeat = now + 1.15 - 0.75 * prox;          // closer = faster
    },

    loot()    { if (!ac) return; tone('square', 420, 420, 0.07, 0.08); tone('square', 640, 640, 0.07, 0.12, 0.09); },
    clink()   { if (!ac) return; tone('triangle', 1300, 1250, 0.12, 0.25); tone('triangle', 1950, 1900, 0.06, 0.2, 0.03); },
    extract() { if (!ac) return; [330, 440, 660].forEach((f, i) => tone('sine', f, f, 0.12, 0.35, i * 0.14)); },

    /** Caught: crushing static plus a falling growl. */
    caught() {
      if (!ac) return;
      noise('lowpass', 1800, 0.4, 1.4);
      tone('sawtooth', 220, 38, 0.25, 1.0);
      tone('square', 90, 30, 0.12, 1.2);
    },

    /** JUMPSCARE: sudden loud shriek + bass hit. */
    jumpscare() {
      if (!ac) return;
      noise('bandpass', 1800, 0.55, 0.9, 0, 2);
      tone('sawtooth', 300, 3200, 0.35, 0.5);
      tone('square', 150, 2800, 0.15, 0.5);
      tone('sine', 55, 30, 0.7, 0.8);
    },

    toggleMute() {
      muted = !muted;
      if (master) master.gain.value = muted ? 0 : 0.7;
    }
  };

  window.Sfx = Sfx;
  window.addEventListener('keydown', e => { if (e.key.toLowerCase() === 'm' && !e.repeat) Sfx.toggleMute(); });
})();
