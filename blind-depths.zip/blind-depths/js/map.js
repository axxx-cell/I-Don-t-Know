'use strict';
/* ==========================================================
   map.js - The world grid.
   - Procedurally generated maze corridors (new layout every run)
   - Tile types: wall, floor, broken glass (sound trap)
   - Loot boxes placed in the farthest DEAD ENDS
   - Elevator (extraction zone) room in the top-left
   - DDA raycasting (used by the flashlight + line-of-sight)
   - Circle-vs-wall collision + BFS pathfinding (used by enemy)
   ========================================================== */

const TILE = 56; // size of one grid tile in pixels

// Tile type ids stored in map.grid[row][col]
const T = { WALL: 0, FLOOR: 1, GLASS: 2 };

class GameMap {
  /**
   * @param {number} cols  odd number of columns
   * @param {number} rows  odd number of rows
   * @param {number} lootCount how many loot boxes to place
   */
  constructor(cols = 31, rows = 21, lootCount = 8) {
    this.cols = cols;
    this.rows = rows;
    this.lootCount = lootCount;
    this.width = cols * TILE;   // world size in pixels
    this.height = rows * TILE;
    this.grid = [];
    this.loot = [];             // {col,row,x,y,looted}
    // Elevator room occupies tiles (1..3, 1..3)
    this.elevator = { col: 1, row: 1, w: 3, h: 3 };
    this.elevator.x = TILE; this.elevator.y = TILE;
    this.elevator.pw = 3 * TILE; this.elevator.ph = 3 * TILE;
    this.spawn = { x: 2.5 * TILE, y: 2.5 * TILE };
    this.stalkerSpawn = { x: 0, y: 0 };
    this.generate();
  }

  /* ---------- GENERATION ---------- */
  generate() {
    const { cols, rows } = this;
    // 1) Start with solid wall
    this.grid = Array.from({ length: rows }, () => new Array(cols).fill(T.WALL));

    // 2) Carve a maze with iterative depth-first search on odd cells
    const stack = [[1, 1]];
    this.grid[1][1] = T.FLOOR;
    const dirs = [[2, 0], [-2, 0], [0, 2], [0, -2]];
    while (stack.length) {
      const [cx, cy] = stack[stack.length - 1];
      const opts = dirs.filter(([dx, dy]) => {
        const nx = cx + dx, ny = cy + dy;
        return nx > 0 && ny > 0 && nx < cols - 1 && ny < rows - 1 && this.grid[ny][nx] === T.WALL;
      });
      if (!opts.length) { stack.pop(); continue; }
      const [dx, dy] = opts[Math.floor(Math.random() * opts.length)];
      this.grid[cy + dy / 2][cx + dx / 2] = T.FLOOR; // knock out wall between cells
      this.grid[cy + dy][cx + dx] = T.FLOOR;
      stack.push([cx + dx, cy + dy]);
    }

    // 3) Remove some walls so there are loops (the stalker can circle around you)
    for (let i = 0; i < 40; i++) {
      const x = 1 + Math.floor(Math.random() * (cols - 2));
      const y = 1 + Math.floor(Math.random() * (rows - 2));
      if (this.grid[y][x] !== T.WALL) continue;
      const horiz = this.grid[y][x - 1] === T.FLOOR && this.grid[y][x + 1] === T.FLOOR;
      const vert = this.grid[y - 1][x] === T.FLOOR && this.grid[y + 1][x] === T.FLOOR;
      if (horiz !== vert) this.grid[y][x] = T.FLOOR; // only if it joins exactly two sides
    }

    // 4) Carve the elevator room (open 3x3 area)
    for (let y = 1; y <= 3; y++) for (let x = 1; x <= 3; x++) this.grid[y][x] = T.FLOOR;

    // 5) Distances from the elevator (used to pick far-away loot / stalker spawn)
    const dist = this.bfsDistances(2, 2);

    // 6) Loot goes in dead ends (floor tiles with exactly one open neighbour)
    const deadEnds = [];
    for (let y = 1; y < rows - 1; y++) {
      for (let x = 1; x < cols - 1; x++) {
        if (this.grid[y][x] !== T.FLOOR || this.inElevatorTile(x, y)) continue;
        if (this.openNeighbours(x, y) === 1 && dist[y][x] > 6) deadEnds.push({ x, y, d: dist[y][x] });
      }
    }
    deadEnds.sort((a, b) => b.d - a.d); // farthest first = riskiest
    for (const de of deadEnds) {
      if (this.loot.length >= this.lootCount) break;
      // keep boxes spread out
      if (this.loot.some(l => Math.abs(l.col - de.x) + Math.abs(l.row - de.y) < 6)) continue;
      this.loot.push({
        col: de.x, row: de.y,
        x: (de.x + 0.5) * TILE, y: (de.y + 0.5) * TILE,
        looted: false
      });
    }

    // 7) Scatter broken glass on corridor tiles (not in elevator, not on loot)
    for (let y = 1; y < rows - 1; y++) {
      for (let x = 1; x < cols - 1; x++) {
        if (this.grid[y][x] !== T.FLOOR || this.inElevatorTile(x, y) || dist[y][x] < 4) continue;
        if (this.loot.some(l => l.col === x && l.row === y)) continue;
        if (Math.random() < 0.09) this.grid[y][x] = T.GLASS;
      }
    }

    // 8) The Stalker starts at the farthest reachable tile
    let best = { x: cols - 2, y: rows - 2, d: -1 };
    for (let y = 1; y < rows - 1; y++)
      for (let x = 1; x < cols - 1; x++)
        if (this.grid[y][x] !== T.WALL && dist[y][x] > best.d) best = { x, y, d: dist[y][x] };
    this.stalkerSpawn = { x: (best.x + 0.5) * TILE, y: (best.y + 0.5) * TILE };
    this.buildTints(dist);   // colour zones (blue near the elevator -> violet -> crimson far away)
    this.buildLamps(dist);   // coloured lamps that light the corridors
  }

  inElevatorTile(c, r) { return c >= 1 && c <= 3 && r >= 1 && r <= 3; }

  openNeighbours(c, r) {
    let n = 0;
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) if (this.grid[r + dy][c + dx] !== T.WALL) n++;
    return n;
  }

  /** BFS distance (in tiles) from a start tile to every reachable tile. */
  bfsDistances(sc, sr) {
    const d = Array.from({ length: this.rows }, () => new Array(this.cols).fill(Infinity));
    const q = [[sc, sr]]; d[sr][sc] = 0;
    for (let i = 0; i < q.length; i++) {
      const [c, r] = q[i];
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nc = c + dx, nr = r + dy;
        if (this.isWallTile(nc, nr) || d[nr][nc] !== Infinity) continue;
        d[nr][nc] = d[r][c] + 1; q.push([nc, nr]);
      }
    }
    return d;
  }

  /* ---------- QUERIES ---------- */
  isWallTile(c, r) {
    if (c < 0 || r < 0 || c >= this.cols || r >= this.rows) return true;
    return this.grid[r][c] === T.WALL;
  }
  tileAt(px, py) {
    const c = Math.floor(px / TILE), r = Math.floor(py / TILE);
    if (c < 0 || r < 0 || c >= this.cols || r >= this.rows) return T.WALL;
    return this.grid[r][c];
  }
  isGlassAt(px, py) { return this.tileAt(px, py) === T.GLASS; }
  inElevator(px, py) {
    const e = this.elevator;
    return px >= e.x && px <= e.x + e.pw && py >= e.y && py <= e.y + e.ph;
  }
  /** Random walkable tile centre (stalker patrol targets). */
  randomFloorPoint() {
    for (let i = 0; i < 200; i++) {
      const c = 1 + Math.floor(Math.random() * (this.cols - 2));
      const r = 1 + Math.floor(Math.random() * (this.rows - 2));
      if (this.grid[r][c] !== T.WALL && !this.inElevatorTile(c, r)) return { x: (c + 0.5) * TILE, y: (r + 0.5) * TILE };
    }
    return { ...this.stalkerSpawn };
  }
  /** Reset all loot boxes (called when a new run starts). */
  resetLoot() { for (const l of this.loot) l.looted = false; }

  /* ---------- COLLISION ---------- */
  /** Does a circle at (x,y) with radius r overlap any wall tile? */
  collidesCircle(x, y, r) {
    const c0 = Math.floor((x - r) / TILE), c1 = Math.floor((x + r) / TILE);
    const r0 = Math.floor((y - r) / TILE), r1 = Math.floor((y + r) / TILE);
    for (let row = r0; row <= r1; row++) {
      for (let col = c0; col <= c1; col++) {
        if (!this.isWallTile(col, row)) continue;
        // closest point on the tile rectangle to the circle centre
        const nx = Math.max(col * TILE, Math.min(x, (col + 1) * TILE));
        const ny = Math.max(row * TILE, Math.min(y, (row + 1) * TILE));
        const dx = x - nx, dy = y - ny;
        if (dx * dx + dy * dy < r * r) return true;
      }
    }
    return false;
  }
  /** Move a circle by (dx,dy), sliding along walls (axes resolved separately). */
  moveCircle(ent, dx, dy, r) {
    if (!this.collidesCircle(ent.x + dx, ent.y, r)) ent.x += dx;
    if (!this.collidesCircle(ent.x, ent.y + dy, r)) ent.y += dy;
  }

  /* ---------- RAYCAST (DDA grid traversal) ---------- */
  /**
   * Cast a ray from (ox,oy) at `angle`. Returns distance (px) to the first
   * wall, capped at maxDist. This is what makes light stop at walls.
   */
  raycast(ox, oy, angle, maxDist) {
    let dx = Math.cos(angle), dy = Math.sin(angle);
    if (Math.abs(dx) < 1e-9) dx = 1e-9; // avoid divide-by-zero
    if (Math.abs(dy) < 1e-9) dy = 1e-9;
    const px = ox / TILE, py = oy / TILE;             // origin in tile units
    let mx = Math.floor(px), my = Math.floor(py);     // current tile
    const ddx = Math.abs(1 / dx), ddy = Math.abs(1 / dy); // ray length per tile step
    let stepX, stepY, sideX, sideY;
    if (dx < 0) { stepX = -1; sideX = (px - mx) * ddx; } else { stepX = 1; sideX = (mx + 1 - px) * ddx; }
    if (dy < 0) { stepY = -1; sideY = (py - my) * ddy; } else { stepY = 1; sideY = (my + 1 - py) * ddy; }
    const maxT = maxDist / TILE;
    let t = 0;
    while (t < maxT) {
      if (sideX < sideY) { t = sideX; sideX += ddx; mx += stepX; }
      else { t = sideY; sideY += ddy; my += stepY; }
      if (this.isWallTile(mx, my)) return Math.min(t * TILE, maxDist);
    }
    return maxDist;
  }
  /** True if nothing solid lies between the two points. */
  hasLineOfSight(x1, y1, x2, y2) {
    const dx = x2 - x1, dy = y2 - y1;
    const d = Math.hypot(dx, dy);
    return this.raycast(x1, y1, Math.atan2(dy, dx), d) >= d - 1;
  }

  /* ---------- PATHFINDING (BFS on tiles) ---------- */
  /** Returns an array of {x,y} waypoints (tile centres) from A to B, or []. */
  findPath(ax, ay, bx, by) {
    const sc = Math.floor(ax / TILE), sr = Math.floor(ay / TILE);
    const tc = Math.floor(bx / TILE), tr = Math.floor(by / TILE);
    if (this.isWallTile(sc, sr) || this.isWallTile(tc, tr)) return [];
    const prev = new Map(); const key = (c, r) => r * this.cols + c;
    const q = [[sc, sr]]; prev.set(key(sc, sr), null);
    for (let i = 0; i < q.length; i++) {
      const [c, r] = q[i];
      if (c === tc && r === tr) break;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nc = c + dx, nr = r + dy;
        if (this.isWallTile(nc, nr) || prev.has(key(nc, nr))) continue;
        prev.set(key(nc, nr), [c, r]); q.push([nc, nr]);
      }
    }
    if (!prev.has(key(tc, tr))) return [];
    const path = []; let cur = [tc, tr];
    while (cur) { path.push({ x: (cur[0] + 0.5) * TILE, y: (cur[1] + 0.5) * TILE }); cur = prev.get(key(cur[0], cur[1])); }
    return path.reverse();
  }

  /* ---------- COLOUR + LAMPS ---------- */
  /** Per-tile colours. Hue shifts with distance from the elevator, so every area feels different. */
  buildTints(dist) {
    this.tint = Array.from({ length: this.rows }, () => new Array(this.cols).fill(null));
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        let dd = dist[r][c];
        if (!isFinite(dd)) {                                   // walls: borrow the nearest floor's distance
          dd = Infinity;
          for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
            const nr = r + dy, nc = c + dx;
            if (nr >= 0 && nc >= 0 && nr < this.rows && nc < this.cols && isFinite(dist[nr][nc])) dd = Math.min(dd, dist[nr][nc]);
          }
          if (!isFinite(dd)) dd = 0;
        }
        const hue = 205 + Math.min(1, dd / 48) * 135;          // blue -> violet -> magenta/crimson
        this.tint[r][c] = {
          floorA: `hsl(${hue},40%,17%)`, floorB: `hsl(${hue},40%,20%)`,
          wall: `hsl(${hue},32%,27%)`, wallHi: `hsl(${hue},40%,36%)`,
          trim: `hsl(${(hue + 25) % 360},80%,52%)`
        };
      }
    }
  }

  /** Coloured ceiling lamps: 4 cyan ones around the elevator + random ones in the maze (some flicker). */
  buildLamps(dist) {
    const pal = [[255, 59, 78], [77, 232, 255], [179, 107, 255], [255, 179, 71], [255, 79, 216]];
    this.lamps = [];
    for (const [c, r] of [[1, 1], [3, 1], [1, 3], [3, 3]])
      this.lamps.push({ x: (c + 0.5) * TILE, y: (r + 0.5) * TILE, rgb: '77,232,255', r: 150, phase: c + r, flicker: false });
    let tries = 0;
    while (this.lamps.length < 18 && tries++ < 500) {
      const c = 1 + Math.floor(Math.random() * (this.cols - 2)), r = 1 + Math.floor(Math.random() * (this.rows - 2));
      if (this.grid[r][c] === T.WALL || this.inElevatorTile(c, r) || dist[r][c] < 5) continue;
      const x = (c + 0.5) * TILE, y = (r + 0.5) * TILE;
      if (this.lamps.some(L => Math.hypot(L.x - x, L.y - y) < TILE * 5)) continue;   // keep them spread out
      this.lamps.push({ x, y, rgb: pal[Math.floor(Math.random() * pal.length)].join(','),
        r: 130 + Math.random() * 50, phase: Math.random() * 6, flicker: Math.random() < 0.35 });
    }
  }

  /* ---------- RENDERING ---------- */
  /**
   * Draw the world: zone-coloured floors, neon-trimmed walls, glass, elevator, loot.
   * The darkness overlay (player.js) hides what the flashlight does not reach.
   */
  draw(ctx, cam, vw, vh, t) {
    const c0 = Math.max(0, Math.floor(cam.x / TILE)), c1 = Math.min(this.cols - 1, Math.floor((cam.x + vw) / TILE));
    const r0 = Math.max(0, Math.floor(cam.y / TILE)), r1 = Math.min(this.rows - 1, Math.floor((cam.y + vh) / TILE));
    for (let r = r0; r <= r1; r++) {
      for (let c = c0; c <= c1; c++) {
        const k = this.tint[r][c], x = c * TILE - cam.x, y = r * TILE - cam.y;
        if (this.grid[r][c] === T.WALL) {
          ctx.fillStyle = k.wall; ctx.fillRect(x, y, TILE, TILE);
          ctx.fillStyle = k.wallHi; ctx.fillRect(x, y, TILE, 5);                       // lit top edge
          ctx.strokeStyle = k.trim; ctx.lineWidth = 2; ctx.globalAlpha = 0.75;          // neon trim
          ctx.strokeRect(x + 3, y + 3, TILE - 6, TILE - 6); ctx.globalAlpha = 1;
        } else {
          ctx.fillStyle = (c + r) % 2 ? k.floorA : k.floorB; ctx.fillRect(x, y, TILE, TILE);
          ctx.strokeStyle = 'rgba(255,255,255,0.04)'; ctx.lineWidth = 1; ctx.strokeRect(x, y, TILE, TILE);   // floor seams
          if (this.grid[r][c] === T.GLASS) this.drawGlass(ctx, x, y, c, r, t);
        }
      }
    }

    // Elevator pad: pulsing cyan glow + animated hazard border
    const e = this.elevator, ex = e.x - cam.x, ey = e.y - cam.y;
    ctx.fillStyle = `rgba(77,232,255,${0.12 + 0.06 * Math.sin(t * 2)})`; ctx.fillRect(ex, ey, e.pw, e.ph);
    ctx.lineWidth = 4; ctx.setLineDash([14, 14]);
    ctx.strokeStyle = '#ffc857'; ctx.lineDashOffset = -t * 12; ctx.strokeRect(ex + 5, ey + 5, e.pw - 10, e.ph - 10);
    ctx.strokeStyle = '#15151d'; ctx.lineDashOffset = 14 - t * 12; ctx.strokeRect(ex + 5, ey + 5, e.pw - 10, e.ph - 10);
    ctx.setLineDash([]); ctx.lineDashOffset = 0;
    ctx.fillStyle = '#4de8ff'; ctx.font = 'bold 13px monospace'; ctx.textAlign = 'center';
    ctx.fillText('ELEVATOR', ex + e.pw / 2, ey + e.ph / 2 + 4);

    // Loot crates: metal box, lock, pulsing amber glow
    for (const l of this.loot) {
      const x = l.x - cam.x, y = l.y - cam.y;
      if (x < -TILE || y < -TILE || x > vw + TILE || y > vh + TILE) continue;
      if (!l.looted) {
        const pulse = 0.5 + 0.5 * Math.sin(t * 3 + l.col);
        const glow = ctx.createRadialGradient(x, y, 2, x, y, 42);
        glow.addColorStop(0, `rgba(255,200,87,${0.35 * pulse + 0.1})`); glow.addColorStop(1, 'rgba(255,200,87,0)');
        ctx.fillStyle = glow; ctx.fillRect(x - 42, y - 42, 84, 84);
        ctx.fillStyle = '#a8742e'; ctx.fillRect(x - 15, y - 12, 30, 24);
        ctx.fillStyle = '#d19a4a'; ctx.fillRect(x - 15, y - 12, 30, 8);                 // lid
        ctx.fillStyle = '#5b3b12'; ctx.fillRect(x - 15, y - 3, 30, 2); ctx.fillRect(x - 11, y - 12, 3, 24); ctx.fillRect(x + 8, y - 12, 3, 24);
        ctx.fillStyle = '#fff1b0'; ctx.fillRect(x - 3, y - 5, 6, 6);                     // lock
        ctx.strokeStyle = '#ffd477'; ctx.lineWidth = 2; ctx.strokeRect(x - 15, y - 12, 30, 24);
      } else {
        ctx.fillStyle = '#2b2b36'; ctx.fillRect(x - 15, y - 8, 30, 20);
        ctx.fillStyle = '#3a3a48'; ctx.fillRect(x - 17, y - 14, 30, 6);                  // open lid
        ctx.strokeStyle = '#4a4a5c'; ctx.lineWidth = 2; ctx.strokeRect(x - 15, y - 8, 30, 20);
      }
    }
  }

  /**
   * Coloured lamp light. Drawn AFTER the darkness with additive blending, and clipped
   * by raycasts so the glow stops at walls (just like the flashlight).
   */
  drawLamps(ctx, cam, vw, vh, t) {
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    for (const L of this.lamps) {
      const sx = L.x - cam.x, sy = L.y - cam.y;
      if (sx < -L.r || sy < -L.r || sx > vw + L.r || sy > vh + L.r) continue;
      let k = 0.75 + 0.25 * Math.sin(t * 2 + L.phase);
      if (L.flicker && Math.sin(t * 23 + L.phase * 5) > 0.6) k *= 0.2;                 // faulty lamp
      ctx.beginPath();
      for (let i = 0; i < 24; i++) {
        const a = (i / 24) * Math.PI * 2, d = this.raycast(L.x, L.y, a, L.r);
        const px = sx + Math.cos(a) * d, py = sy + Math.sin(a) * d;
        i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
      }
      ctx.closePath();
      const g = ctx.createRadialGradient(sx, sy, 0, sx, sy, L.r);
      g.addColorStop(0, `rgba(${L.rgb},${0.45 * k})`); g.addColorStop(1, `rgba(${L.rgb},0)`);
      ctx.fillStyle = g; ctx.fill();
      ctx.fillStyle = `rgba(255,255,255,${0.9 * k})`; ctx.beginPath(); ctx.arc(sx, sy, 2.5, 0, Math.PI * 2); ctx.fill();   // bulb
    }
    ctx.restore();
  }

  /** Glass shards (fixed positions) with twinkling highlights. */
  drawGlass(ctx, x, y, c, r, t) {
    ctx.strokeStyle = 'rgba(170,235,255,0.8)'; ctx.lineWidth = 1;
    for (let i = 0; i < 6; i++) {
      const s = Math.sin(c * 12.9898 + r * 78.233 + i * 3.1) * 43758.5453; const f = s - Math.floor(s);
      const s2 = Math.sin(c * 4.1 + r * 9.7 + i * 7.7) * 15731.7; const g = s2 - Math.floor(s2);
      const px = x + 8 + f * (TILE - 16), py = y + 8 + g * (TILE - 16);
      ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px + 6 * (f - .5) * 2, py + 6 * (g - .5) * 2); ctx.lineTo(px + 5, py + 4); ctx.closePath(); ctx.stroke();
      if (i < 3) {                                                                      // sparkle
        ctx.fillStyle = `rgba(255,255,255,${0.5 + 0.5 * Math.sin(t * 4 + c * 3 + r + i * 2)})`;
        ctx.fillRect(px - 1, py - 1, 2, 2);
      }
    }
  }
}
