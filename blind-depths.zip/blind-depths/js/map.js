'use strict';
/* ==========================================================
   map.js - The world grid.
   - Procedurally generated maze corridors (new layout every run)
   - Tile types: wall, floor, broken glass (sound trap)
   - Loot boxes placed in the farthest DEAD ENDS
   - Elevator (extraction zone) room in the top-left
   - DDA raycasting (used by the flashlight + line-of-sight)
   - Circle-vs-wall collision + BFS pathfinding (used by enemy)
   ========================================================== */

const TILE = 56; // size of one grid tile in pixels

// Tile type ids stored in map.grid[row][col]
const T = { WALL: 0, FLOOR: 1, GLASS: 2 };

class GameMap {
  /**
   * @param {number} cols  odd number of columns
   * @param {number} rows  odd number of rows
   * @param {number} lootCount how many loot boxes to place
   */
  constructor(cols = 31, rows = 21, lootCount = 8) {
    this.cols = cols;
    this.rows = rows;
    this.lootCount = lootCount;
    this.width = cols * TILE;   // world size in pixels
    this.height = rows * TILE;
    this.grid = [];
    this.loot = [];             // {col,row,x,y,looted}
    // Elevator room occupies tiles (1..3, 1..3)
    this.elevator = { col: 1, row: 1, w: 3, h: 3 };
    this.elevator.x = TILE; this.elevator.y = TILE;
    this.elevator.pw = 3 * TILE; this.elevator.ph = 3 * TILE;
    this.spawn = { x: 2.5 * TILE, y: 2.5 * TILE };
    this.stalkerSpawn = { x: 0, y: 0 };
    this.generate();
  }

  /* ---------- GENERATION ---------- */
  generate() {
    const { cols, rows } = this;
    // 1) Start with solid wall
    this.grid = Array.from({ length: rows }, () => new Array(cols).fill(T.WALL));

    // 2) Carve a maze with iterative depth-first search on odd cells
    const stack = [[1, 1]];
    this.grid[1][1] = T.FLOOR;
    const dirs = [[2, 0], [-2, 0], [0, 2], [0, -2]];
    while (stack.length) {
      const [cx, cy] = stack[stack.length - 1];
      const opts = dirs.filter(([dx, dy]) => {
        const nx = cx + dx, ny = cy + dy;
        return nx > 0 && ny > 0 && nx < cols - 1 && ny < rows - 1 && this.grid[ny][nx] === T.WALL;
      });
      if (!opts.length) { stack.pop(); continue; }
      const [dx, dy] = opts[Math.floor(Math.random() * opts.length)];
      this.grid[cy + dy / 2][cx + dx / 2] = T.FLOOR; // knock out wall between cells
      this.grid[cy + dy][cx + dx] = T.FLOOR;
      stack.push([cx + dx, cy + dy]);
    }

    // 3) Remove some walls so there are loops (the stalker can circle around you)
    for (let i = 0; i < 40; i++) {
      const x = 1 + Math.floor(Math.random() * (cols - 2));
      const y = 1 + Math.floor(Math.random() * (rows - 2));
      if (this.grid[y][x] !== T.WALL) continue;
      const horiz = this.grid[y][x - 1] === T.FLOOR && this.grid[y][x + 1] === T.FLOOR;
      const vert = this.grid[y - 1][x] === T.FLOOR && this.grid[y + 1][x] === T.FLOOR;
      if (horiz !== vert) this.grid[y][x] = T.FLOOR; // only if it joins exactly two sides
    }

    // 4) Carve the elevator room (open 3x3 area)
    for (let y = 1; y <= 3; y++) for (let x = 1; x <= 3; x++) this.grid[y][x] = T.FLOOR;

    // 5) Distances from the elevator (used to pick far-away loot / stalker spawn)
    const dist = this.bfsDistances(2, 2);

    // 6) Loot goes in dead ends (floor tiles with exactly one open neighbour)
    const deadEnds = [];
    for (let y = 1; y < rows - 1; y++) {
      for (let x = 1; x < cols - 1; x++) {
        if (this.grid[y][x] !== T.FLOOR || this.inElevatorTile(x, y)) continue;
        if (this.openNeighbours(x, y) === 1 && dist[y][x] > 6) deadEnds.push({ x, y, d: dist[y][x] });
      }
    }
    deadEnds.sort((a, b) => b.d - a.d); // farthest first = riskiest
    for (const de of deadEnds) {
      if (this.loot.length >= this.lootCount) break;
      // keep boxes spread out
      if (this.loot.some(l => Math.abs(l.col - de.x) + Math.abs(l.row - de.y) < 6)) continue;
      this.loot.push({
        col: de.x, row: de.y,
        x: (de.x + 0.5) * TILE, y: (de.y + 0.5) * TILE,
        looted: false
      });
    }

    // 7) Scatter broken glass on corridor tiles (not in elevator, not on loot)
    for (let y = 1; y < rows - 1; y++) {
      for (let x = 1; x < cols - 1; x++) {
        if (this.grid[y][x] !== T.FLOOR || this.inElevatorTile(x, y) || dist[y][x] < 4) continue;
        if (this.loot.some(l => l.col === x && l.row === y)) continue;
        if (Math.random() < 0.09) this.grid[y][x] = T.GLASS;
      }
    }

    // 8) The Stalker starts at the farthest reachable tile
    let best = { x: cols - 2, y: rows - 2, d: -1 };
    for (let y = 1; y < rows - 1; y++)
      for (let x = 1; x < cols - 1; x++)
        if (this.grid[y][x] !== T.WALL && dist[y][x] > best.d) best = { x, y, d: dist[y][x] };
    this.stalkerSpawn = { x: (best.x + 0.5) * TILE, y: (best.y + 0.5) * TILE };
  }

  inElevatorTile(c, r) { return c >= 1 && c <= 3 && r >= 1 && r <= 3; }

  openNeighbours(c, r) {
    let n = 0;
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) if (this.grid[r + dy][c + dx] !== T.WALL) n++;
    return n;
  }

  /** BFS distance (in tiles) from a start tile to every reachable tile. */
  bfsDistances(sc, sr) {
    const d = Array.from({ length: this.rows }, () => new Array(this.cols).fill(Infinity));
    const q = [[sc, sr]]; d[sr][sc] = 0;
    for (let i = 0; i < q.length; i++) {
      const [c, r] = q[i];
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nc = c + dx, nr = r + dy;
        if (this.isWallTile(nc, nr) || d[nr][nc] !== Infinity) continue;
        d[nr][nc] = d[r][c] + 1; q.push([nc, nr]);
      }
    }
    return d;
  }

  /* ---------- QUERIES ---------- */
  isWallTile(c, r) {
    if (c < 0 || r < 0 || c >= this.cols || r >= this.rows) return true;
    return this.grid[r][c] === T.WALL;
  }
  tileAt(px, py) {
    const c = Math.floor(px / TILE), r = Math.floor(py / TILE);
    if (c < 0 || r < 0 || c >= this.cols || r >= this.rows) return T.WALL;
    return this.grid[r][c];
  }
  isGlassAt(px, py) { return this.tileAt(px, py) === T.GLASS; }
  inElevator(px, py) {
    const e = this.elevator;
    return px >= e.x && px <= e.x + e.pw && py >= e.y && py <= e.y + e.ph;
  }
  /** Random walkable tile centre (stalker patrol targets). */
  randomFloorPoint() {
    for (let i = 0; i < 200; i++) {
      const c = 1 + Math.floor(Math.random() * (this.cols - 2));
      const r = 1 + Math.floor(Math.random() * (this.rows - 2));
      if (this.grid[r][c] !== T.WALL && !this.inElevatorTile(c, r)) return { x: (c + 0.5) * TILE, y: (r + 0.5) * TILE };
    }
    return { ...this.stalkerSpawn };
  }
  /** Reset all loot boxes (called when a new run starts). */
  resetLoot() { for (const l of this.loot) l.looted = false; }

  /* ---------- COLLISION ---------- */
  /** Does a circle at (x,y) with radius r overlap any wall tile? */
  collidesCircle(x, y, r) {
    const c0 = Math.floor((x - r) / TILE), c1 = Math.floor((x + r) / TILE);
    const r0 = Math.floor((y - r) / TILE), r1 = Math.floor((y + r) / TILE);
    for (let row = r0; row <= r1; row++) {
      for (let col = c0; col <= c1; col++) {
        if (!this.isWallTile(col, row)) continue;
        // closest point on the tile rectangle to the circle centre
        const nx = Math.max(col * TILE, Math.min(x, (col + 1) * TILE));
        const ny = Math.max(row * TILE, Math.min(y, (row + 1) * TILE));
        const dx = x - nx, dy = y - ny;
        if (dx * dx + dy * dy < r * r) return true;
      }
    }
    return false;
  }
  /** Move a circle by (dx,dy), sliding along walls (axes resolved separately). */
  moveCircle(ent, dx, dy, r) {
    if (!this.collidesCircle(ent.x + dx, ent.y, r)) ent.x += dx;
    if (!this.collidesCircle(ent.x, ent.y + dy, r)) ent.y += dy;
  }

  /* ---------- RAYCAST (DDA grid traversal) ---------- */
  /**
   * Cast a ray from (ox,oy) at `angle`. Returns distance (px) to the first
   * wall, capped at maxDist. This is what makes light stop at walls.
   */
  raycast(ox, oy, angle, maxDist) {
    let dx = Math.cos(angle), dy = Math.sin(angle);
    if (Math.abs(dx) < 1e-9) dx = 1e-9; // avoid divide-by-zero
    if (Math.abs(dy) < 1e-9) dy = 1e-9;
    const px = ox / TILE, py = oy / TILE;             // origin in tile units
    let mx = Math.floor(px), my = Math.floor(py);     // current tile
    const ddx = Math.abs(1 / dx), ddy = Math.abs(1 / dy); // ray length per tile step
    let stepX, stepY, sideX, sideY;
    if (dx < 0) { stepX = -1; sideX = (px - mx) * ddx; } else { stepX = 1; sideX = (mx + 1 - px) * ddx; }
    if (dy < 0) { stepY = -1; sideY = (py - my) * ddy; } else { stepY = 1; sideY = (my + 1 - py) * ddy; }
    const maxT = maxDist / TILE;
    let t = 0;
    while (t < maxT) {
      if (sideX < sideY) { t = sideX; sideX += ddx; mx += stepX; }
      else { t = sideY; sideY += ddy; my += stepY; }
      if (this.isWallTile(mx, my)) return Math.min(t * TILE, maxDist);
    }
    return maxDist;
  }
  /** True if nothing solid lies between the two points. */
  hasLineOfSight(x1, y1, x2, y2) {
    const dx = x2 - x1, dy = y2 - y1;
    const d = Math.hypot(dx, dy);
    return this.raycast(x1, y1, Math.atan2(dy, dx), d) >= d - 1;
  }

  /* ---------- PATHFINDING (BFS on tiles) ---------- */
  /** Returns an array of {x,y} waypoints (tile centres) from A to B, or []. */
  findPath(ax, ay, bx, by) {
    const sc = Math.floor(ax / TILE), sr = Math.floor(ay / TILE);
    const tc = Math.floor(bx / TILE), tr = Math.floor(by / TILE);
    if (this.isWallTile(sc, sr) || this.isWallTile(tc, tr)) return [];
    const prev = new Map(); const key = (c, r) => r * this.cols + c;
    const q = [[sc, sr]]; prev.set(key(sc, sr), null);
    for (let i = 0; i < q.length; i++) {
      const [c, r] = q[i];
      if (c === tc && r === tr) break;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nc = c + dx, nr = r + dy;
        if (this.isWallTile(nc, nr) || prev.has(key(nc, nr))) continue;
        prev.set(key(nc, nr), [c, r]); q.push([nc, nr]);
      }
    }
    if (!prev.has(key(tc, tr))) return [];
    const path = []; let cur = [tc, tr];
    while (cur) { path.push({ x: (cur[0] + 0.5) * TILE, y: (cur[1] + 0.5) * TILE }); cur = prev.get(key(cur[0], cur[1])); }
    return path.reverse();
  }

  /* ---------- RENDERING ---------- */
  /**
   * Draw the world (walls, floor, glass, loot, elevator).
   * Only tiles inside the camera view are drawn (cheap). The darkness
   * overlay (player.js) hides everything outside the flashlight.
   */
  draw(ctx, cam, vw, vh, time) {
    const c0 = Math.max(0, Math.floor(cam.x / TILE)), c1 = Math.min(this.cols - 1, Math.floor((cam.x + vw) / TILE));
    const r0 = Math.max(0, Math.floor(cam.y / TILE)), r1 = Math.min(this.rows - 1, Math.floor((cam.y + vh) / TILE));
    for (let r = r0; r <= r1; r++) {
      for (let c = c0; c <= c1; c++) {
        const t = this.grid[r][c];
        const x = c * TILE - cam.x, y = r * TILE - cam.y;
        if (t === T.WALL) {
          ctx.fillStyle = '#3a4757'; ctx.fillRect(x, y, TILE, TILE);
          ctx.strokeStyle = '#566579'; ctx.lineWidth = 2; ctx.strokeRect(x + 1, y + 1, TILE - 2, TILE - 2);
        } else {
          ctx.fillStyle = (c + r) % 2 ? '#1f2a35' : '#222e3a'; ctx.fillRect(x, y, TILE, TILE);
          if (t === T.GLASS) this.drawGlass(ctx, x, y, c, r);
        }
      }
    }
    // Elevator pad
    const e = this.elevator;
    ctx.fillStyle = 'rgba(93,255,166,0.12)'; ctx.fillRect(e.x - cam.x, e.y - cam.y, e.pw, e.ph);
    ctx.strokeStyle = '#5dffa6'; ctx.lineWidth = 2; ctx.setLineDash([10, 8]);
    ctx.strokeRect(e.x - cam.x + 4, e.y - cam.y + 4, e.pw - 8, e.ph - 8); ctx.setLineDash([]);
    ctx.fillStyle = '#5dffa6'; ctx.font = '12px monospace'; ctx.textAlign = 'center';
    ctx.fillText('ELEVATOR', e.x - cam.x + e.pw / 2, e.y - cam.y + e.ph / 2 + 4);

    // Loot boxes
    for (const l of this.loot) {
      const x = l.x - cam.x, y = l.y - cam.y;
      if (x < -TILE || y < -TILE || x > vw + TILE || y > vh + TILE) continue;
      ctx.fillStyle = l.looted ? '#2b2b2b' : '#8a6a2f';
      ctx.fillRect(x - 14, y - 11, 28, 22);
      ctx.strokeStyle = l.looted ? '#444' : '#ffc857'; ctx.lineWidth = 2; ctx.strokeRect(x - 14, y - 11, 28, 22);
      if (!l.looted) { ctx.fillStyle = '#ffc857'; ctx.fillRect(x - 3, y - 3, 6, 6); }
    }
  }

  /** Little shards drawn deterministically from the tile coords (no flicker). */
  drawGlass(ctx, x, y, c, r) {
    ctx.strokeStyle = 'rgba(190,230,255,0.7)'; ctx.lineWidth = 1;
    for (let i = 0; i < 6; i++) {
      const s = Math.sin(c * 12.9898 + r * 78.233 + i * 3.1) * 43758.5453; const f = s - Math.floor(s);
      const s2 = Math.sin(c * 4.1 + r * 9.7 + i * 7.7) * 15731.7; const g = s2 - Math.floor(s2);
      const px = x + 8 + f * (TILE - 16), py = y + 8 + g * (TILE - 16);
      ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px + 6 * (f - .5) * 2, py + 6 * (g - .5) * 2); ctx.lineTo(px + 5, py + 4); ctx.closePath(); ctx.stroke();
    }
  }
}
